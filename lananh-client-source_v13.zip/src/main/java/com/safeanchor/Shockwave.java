package com.safeanchor;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Khi nhảy lên / tiếp đất: vòng khối (block) nâng lên rồi hạ xuống lan ra xung quanh. */
public class Shockwave {
    static class Wave { Vec3d pos; BlockState st; int t; }
    static final List<Wave> waves = new ArrayList<>();
    static boolean prevGround = true;
    static double prevFall;

    static void start(MinecraftClient mc) {
        var p = mc.player;
        Wave w = new Wave(); w.pos = p.getPos();
        BlockPos below = p.getBlockPos().down();
        BlockState st = mc.world.getBlockState(below);
        w.st = st.isAir() || st.isReplaceable() ? Blocks.STONE.getDefaultState() : st;
        waves.add(w);
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.shockOn || p == null || mc.world == null) { waves.clear(); return; }
        boolean g = p.isOnGround();
        if (prevGround && !g && p.getVelocity().y > 0.1 && c.shockJump) start(mc);
        if (!prevGround && g && prevFall >= c.shockMinFall && c.shockLand) start(mc);
        if (!g) prevFall = (double) p.fallDistance;
        prevGround = g;

        for (int k = waves.size() - 1; k >= 0; k--) {
            Wave w = waves.get(k);
            w.t++;
            double frac = w.t / (double) Math.max(2, c.shockTicks);
            if (frac > 1.0) { waves.remove(k); continue; }
            double r = frac * c.shockRadius;
            double h = Math.sin(Math.PI * frac) * c.shockHeight;      // nâng lên rồi hạ xuống
            int n = (int) (10 + r * 8);
            if (c.shockBlock) continue;      // chế độ khối: vẽ khối thật trong render()
            for (int i = 0; i < n; i++) {
                double a = Math.PI * 2 * i / n;
                double x = w.pos.x + Math.cos(a) * r, z = w.pos.z + Math.sin(a) * r;
                ParticleEffect fx;
                if (c.shockBlock) fx = new BlockStateParticleEffect(ParticleTypes.BLOCK, w.st);
                else fx = new DustParticleEffect(c.chroma ? Util.chroma(i * 0.02) : c.shockColor, 1.6f);
                mc.world.addParticle(fx, x, w.pos.y + 0.1 + h, z, 0, 0.01, 0);
            }
        }
    }

    /** Chế độ khối: các khối thật nhô lên nhanh rồi rớt xuống từ từ, lan ra thành vòng. */
    public static void render(WorldRenderContext ctx) {
        Config c = Config.I; MinecraftClient mc = MinecraftClient.getInstance();
        if (!c.shockOn || !c.shockBlock || !c.enabled || waves.isEmpty() || mc.world == null) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vc = ctx.consumers();
        if (ms == null || vc == null) return;
        Vec3d cp = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(false);
        double total = Math.max(2, c.shockTicks);
        for (Wave w : waves) {
            double f = (w.t + td) / total;
            if (f < 0 || f > 1) continue;
            double r = f * c.shockRadius;
            double h = Math.sin(Math.PI * Math.pow(f, 0.6)) * c.shockHeight;   // lên nhanh, xuống chậm
            int n = (int) Math.max(8, 8 + r * 7);
            float s = (float) (0.36 * (1.0 - 0.35 * f));
            for (int i = 0; i < n; i++) {
                double a = Math.PI * 2 * i / n;
                double x = w.pos.x + Math.cos(a) * r - cp.x - s / 2.0;
                double y = w.pos.y + h - cp.y;
                double z = w.pos.z + Math.sin(a) * r - cp.z - s / 2.0;
                ms.push();
                ms.translate(x, y, z);
                ms.scale(s, s, s);
                mc.getBlockRenderManager().renderBlockAsEntity(w.st, ms, vc, LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV);
                ms.pop();
            }
        }
        if (vc instanceof VertexConsumerProvider.Immediate im) im.draw();
    }
}
