package com.safeanchor;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Hình 2D (nhìn ngang) minh họa đường bay của Elytra Mace theo đúng cài đặt hiện tại - chỉnh gì là hình đổi theo. */
public class MacePreview {
    record Pt(double x, double y, boolean rk) {}

    static class Path { final List<Pt> pts = new ArrayList<>(); int swap = -1, hit = -1; double tx; }

    static void seg(Path p, double x0, double y0, double x1, double y1, boolean rk) {
        double len = Math.hypot(x1 - x0, y1 - y0);
        int n = Math.max(1, (int) (len / 0.6));
        if (p.pts.isEmpty()) p.pts.add(new Pt(x0, y0, rk));
        for (int i = 1; i <= n; i++) p.pts.add(new Pt(x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, rk));
    }

    static Path build(Config c) {
        Path p = new Path();
        double T = c.maceChase ? 48 : 40;
        double hd = Math.max(4, Math.min(40, c.maceHorizDive));
        double H = Math.min(46, c.maceDiveDist + 8);
        double bx = Math.max(6, T - hd - 6);
        p.tx = T;
        seg(p, 2, 0, bx, H, true);                                         // bay lên (pháo)
        if (c.maceStyle == 1) {                                            // LAO PHÁO: lao chéo xuống có pháo
            seg(p, bx, H, T, 1.8, true);
            p.hit = p.pts.size() - 1;
            double sw = Math.max(2, c.maceSwapDist);
            for (int i = p.hit; i >= 0; i--) if (Math.hypot(p.pts.get(i).x() - T, p.pts.get(i).y() - 1.8) >= sw) { p.swap = i; break; }
        } else {                                                           // THẢ RƠI: bay ngang trên đầu rồi rơi thẳng
            double dx = Math.max(2, Math.min(8, hd * 0.2));
            seg(p, bx, H, T - dx, H, false);
            p.swap = p.pts.size() - 1;
            int n = 40;
            for (int i = 1; i <= n; i++) { double s = i / (double) n; p.pts.add(new Pt(T - dx + dx * s, H - (H - 1.8) * s * s, false)); }
            p.hit = p.pts.size() - 1;
        }
        seg(p, T, 1.8, Math.min(58, T + 10), H, true);                     // đánh xong: bay lên lại
        return p;
    }

    public static void draw(DrawContext ctx, TextRenderer tr, int X, int Y, int W, int H) {
        Config c = Config.I;
        ctx.fill(X, Y, X + W, Y + H, 0xFF12121E);
        ctx.fill(X, Y, X + W, Y + 1, 0xFF8B5CF6); ctx.fill(X, Y + H - 1, X + W, Y + H, 0xFF8B5CF6);
        int gx0 = X + 8, gx1 = X + W - 8, gy = Y + H - 10, top = Y + 16;
        double sx = (gx1 - gx0) / 60.0, sy = (gy - top) / 50.0;
        ctx.fill(gx0, gy, gx1, gy + 1, 0xFF555570);

        Path p = build(c);
        int n = p.pts.size();
        int cur = (int) ((System.currentTimeMillis() % 7000L) / 7000.0 * n);
        // đường bay: mờ = chưa tới, sáng = đã bay
        for (int i = 0; i < n; i += 2) {
            Pt q = p.pts.get(i);
            int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
            ctx.fill(px, py, px + 1, py + 1, i <= cur ? 0xFFC8A8FF : 0xFF444466);
        }
        // pháo: vệt cam phía sau
        for (int i = Math.max(0, cur - 8); i <= cur && i < n; i++) {
            Pt q = p.pts.get(i);
            if (!q.rk()) continue;
            int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
            ctx.fill(px - 1, py + 1, px + 1, py + 3, 0xFFFFA030);
        }
        // đối thủ
        int tx = gx0 + (int) (p.tx * sx);
        ctx.fill(tx - 2, gy - 14, tx + 2, gy - 10, 0xFFFFC8A0);
        ctx.fill(tx - 2, gy - 10, tx + 2, gy, 0xFF3FA0FF);
        if (c.maceChase) ctx.drawText(tr, "→", tx + 6, gy - 12, 0xFFFFAA55, false);
        // mốc đổi áo / đánh
        if (p.swap >= 0) { Pt q = p.pts.get(p.swap); int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
            ctx.fill(px - 2, py - 2, px + 2, py + 2, 0xFF40E0FF); ctx.drawText(tr, "áo", px - 6, py - 12, 0xFF40E0FF, false); }
        if (p.hit >= 0) { Pt q = p.pts.get(p.hit); int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
            ctx.fill(px - 3, py - 3, px + 3, py + 3, 0xFFFF4040); ctx.drawText(tr, "đánh", px - 22, py - 4, 0xFFFF6060, false); }
        // người chơi
        if (n > 0) { Pt q = p.pts.get(Math.min(cur, n - 1)); int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
            ctx.fill(px - 2, py - 2, px + 3, py + 3, 0xFFFFFFFF); }
        String t1 = (c.maceStyle == 1 ? "§dLao pháo" : "§bThả rơi") + "§7  cao §f" + (int) (c.maceDiveDist + 8) + "§7  lệch §f" + (int) c.maceHorizDive
                + "§7  đổi §f" + (int) c.maceSwapDist + "§7  đánh §f" + String.format("%.1f", c.maceHitDist);
        ctx.drawText(tr, t1, X + 6, Y + 4, 0xFFFFFFFF, false);
    }
}
