package com.safeanchor;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

public class LanAnhClient implements ClientModInitializer {
    static KeyBinding menuKey, maceKey, anchorKey, printerKey, aimKey, pvpKey, mineKey, comboKey, macroKey, modulesKey;

    static KeyBinding reg(String id, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(id, InputUtil.Type.KEYSYM, key, "category.safeanchor"));
    }

    /** Rương, rương ender, thùng, hopper, shulker, dropper/dispenser, lò, bệ pha thuốc... (mọi block có túi đồ). */
    static boolean isContainer(World w, BlockPos pos) {
        if (w.getBlockState(pos).isOf(Blocks.ENDER_CHEST)) return true;
        return w.getBlockEntity(pos) instanceof Inventory;
    }

    @Override public void onInitializeClient() {
        Config.load();
        menuKey = reg("key.safeanchor.menu", GLFW.GLFW_KEY_RIGHT_SHIFT);
        maceKey = reg("key.safeanchor.mace", GLFW.GLFW_KEY_R);
        anchorKey = reg("key.safeanchor.anchor", GLFW.GLFW_KEY_G);
        printerKey = reg("key.safeanchor.printer", GLFW.GLFW_KEY_P);
        aimKey = reg("key.safeanchor.aimbot", GLFW.GLFW_KEY_B);
        pvpKey = reg("key.safeanchor.pvp", GLFW.GLFW_KEY_V);
        mineKey = reg("key.safeanchor.mine", GLFW.GLFW_KEY_N);
        comboKey = reg("key.safeanchor.combo", GLFW.GLFW_KEY_J);
        macroKey = reg("key.safeanchor.macro", GLFW.GLFW_KEY_K);
        modulesKey = reg("key.safeanchor.modules", GLFW.GLFW_KEY_INSERT);
        ModuleManager.load();
        Translate.init();

        UseBlockCallback.EVENT.register((pl, w, hand, hit) -> {
            if (!w.isClient) return ActionResult.PASS;
            // click rương/hopper/shulker... không mở (ngồi shift để mở). Thao tác do client tự làm (Util.bot) thì bỏ qua.
            if (Config.I.noOpenContainer && Config.I.enabled && !Util.bot && !pl.isSneaking() && isContainer(w, hit.getBlockPos())) return ActionResult.FAIL;
            if (w.getBlockState(hit.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) AnchorShield.onUse(pl, w, hand, hit.getBlockPos());   // nổ anchor -> đặt chắn trước
            if (pl.getStackInHand(hand).isOf(Items.RESPAWN_ANCHOR)) AutoAnchor.onPlace(hit);
            if (pl.getStackInHand(hand).getItem() instanceof net.minecraft.item.BlockItem) Fx.onPlace(hit.getBlockPos().offset(hit.getSide()));
            return ActionResult.PASS;
        });
        net.fabricmc.fabric.api.event.player.AttackEntityCallback.EVENT.register((pl, w, hand, entity, hit) -> {
            if (w.isClient && Config.I.hitSelect && !(entity instanceof net.minecraft.entity.decoration.EndCrystalEntity) && pl.getAttackCooldownProgress(0.5f) < Config.I.hitSelectMin / 100f) return ActionResult.FAIL;
            if (w.isClient) Fx.onHit(entity);
            if (w.isClient && entity instanceof net.minecraft.entity.player.PlayerEntity pe && Config.I.crystal) { AutoCrystal.hitTarget = pe; AutoCrystal.hitTicks = 60; }
            if (w.isClient && entity instanceof net.minecraft.entity.player.PlayerEntity && pl.getMainHandStack().isOf(Items.MACE)) ElytraMace.onHit();
            return ActionResult.PASS;
        });
        WorldRenderEvents.AFTER_TRANSLUCENT.register(SkyBox::render);          // vẽ trước để ESP đè lên trên
        WorldRenderEvents.AFTER_TRANSLUCENT.register(Esp::render);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(BaseScan::render);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(Trail::render);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(Fx::render);
        WorldRenderEvents.AFTER_ENTITIES.register(Shockwave::render);
        HudRenderCallback.EVENT.register(Hud::render);
        HudRenderCallback.EVENT.register(Hud2::render);
        HudRenderCallback.EVENT.register((ctx, tc) -> ModuleManager.hud(ctx));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    void tick(MinecraftClient mc) {
        while (menuKey.wasPressed()) { Anim.start = System.currentTimeMillis(); mc.setScreen(new ModulesScreen(null)); }
        while (modulesKey.wasPressed()) { Anim.start = System.currentTimeMillis(); mc.setScreen(new ModulesScreen(null)); }
        while (maceKey.wasPressed()) ElytraMace.toggle(mc);
        while (anchorKey.wasPressed()) AutoAnchor.toggle(mc);
        while (printerKey.wasPressed()) Printer.toggle(mc);
        while (aimKey.wasPressed()) Aimbot.toggle(mc);
        while (pvpKey.wasPressed()) AutoPvp.toggle(mc);
        while (mineKey.wasPressed()) AutoMine.toggle(mc);
        while (comboKey.wasPressed()) AnchorCombo.start(mc);
        while (macroKey.wasPressed()) MacroBuilder.start(mc);
        ModuleManager.tick(mc);
        if (mc.player == null || mc.world == null) return;
        try {
            ElytraMace.tick(mc);
            WindMace.tick(mc);
            AutoCrystal.tick(mc);
            CrystalMacro.tick(mc);
            HeadHit.tick(mc);
            MacroBuilder.tick(mc);
            AutoAnchor.tick(mc);
            BlockEsp.tick(mc);
            Printer.tick(mc);
            Aimbot.tick(mc);
            Surround.tick(mc);
            AutoPvp.tick(mc);
            AutoMine.tick(mc);
            AutoAh.tick(mc);
            SusChunk.tick(mc);
            Shockwave.tick(mc);
            Trail.tick(mc);
            Velocity.tick(mc);
            Fx.tick(mc);
            Combat2.tick(mc);
            Bridge.tick(mc);
            AnchorCombo.tick(mc);
            TpGlide.tick(mc);
            BaseScan.tick(mc);
            KeySound.tick(mc);
            if (Config.I.skyOn && mc.world != null) mc.world.setTime(mc.world.getTime(), (long) Config.I.skyTime, false);
        } catch (Throwable t) { t.printStackTrace(); }
    }
}
